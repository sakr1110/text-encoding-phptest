<!doctype html>
<html>
<head>
<link href="style.css" type="text/css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<meta charset="utf-8">
<title>Challenge</title>
<script>
$(document).ready(function(){
	
	
	
	
          $('#action-button').click(function() {
    
	localStorage.setItem('history', $('#input-text').val());
	var history = localStorage.getItem("history");
	
	$("ul").append("<li>"+ history + "</li>");
	
			  
			  
			  $.ajax({
            url:'TranspositionEncodingAlgorithm.php', //the page containing php script
            type: "POST", //request type
            data: {text: $('#input-text').val()},
            success:function(data){
	           $('#output-text').val(data);
           }
         });
		  });
		  });
</script>
</head>

<body>
<div class="history">
<h2> History </h2>
<ul>

</ul>
</div>
<div class="container">
<p>Input text</p>

<input type="text" name="text" id="input-text">
<button id="action-button"><img src="image.png" width="40px" height="40px"></button>

<!--honeee-->
<p>Output text </p>
<input type="text" id="output-text" >
</div>
</body>
</html>